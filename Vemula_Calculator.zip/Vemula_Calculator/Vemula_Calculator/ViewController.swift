//
//  ViewController.swift
//  Vemula_Calculator
//
//  Created by Vemula,Ajay Kumar on 2/13/22.
//


import UIKit

class ViewController: UIViewController {


   
    
    @IBOutlet weak var displaylabel: UILabel!
    
    var num1 = ""
    var num2 = ""
    var result = ""
    var operation = ""
    var currNum = ""
    var opChange = false
    var inChainmode = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func AC(_ sender: UIButton) {
        
        clearAll()
    }
    func clearAll(){
        num1 = ""
        num2 = ""
        opChange = false
        operation = ""
        currNum = ""
        displaylabel.text = ""
        inChainmode = false
    }
    func setData(_ number: String){
        if displaylabel.text == "0"{
            displaylabel.text = ""
        }
        else{
            if !opChange{
               displaylabel.text! += number
                num1 += number
            }
            else{
                if !inChainmode{
                    displaylabel.text! += number
                    num2 += number
                }
                else{
                    displaylabel.text = ""
                    displaylabel.text! += number
                    num2 += number
                }
            }
        }
    }
    
    func calTemp(_ operation:String)->String {
        if num1 != "" && num2 != ""{
            if operation == "+"{
                num1 = String(Double(num1)! + Double(num2)!)
                currNum = num2
                num2 = ""
                return String(num1)
            }
            if operation == "-"{
                num1 = String(Double(num1)! - Double(num2)!)
                currNum = num2
                num2 = ""
                
                return String(num1)
            }
            if operation == "*"{
                num1 = String(Double(num1)! * Double(num2)!)
                currNum = num2
                num2 = ""
                return String(num1)
            }
            if operation == "/"{
                num1 = String(Double(num1)! / Double(num2)!)
                currNum = num2
                num2 = ""
                return String(num1)
            }
            if operation == "%" {
                let s1 = Double(num1)!
                let s2 = Double(num2)!
                var r = s1.remainder(dividingBy: s2)
                num1 = String(r)
                currNum = num2
                num2 = ""
                return String(num1)
            }
        }
        return ""
    }
    func resultFormatter(_ result:String)->String {
        let value = Double(result)!
        var resultStr = String(round(value * 100000) / 100000.0)
        
        if resultStr.contains(".0"){
            resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
        }
        
        return resultStr
}
    
    @IBAction func C(_ sender: UIButton) {
        num2 = ""
        displaylabel.text = ""
    }
    @IBAction func plusOrMinus(_ sender: UIButton) {
        let pm = displaylabel.text!
        var RunningTotal = (pm as NSString).doubleValue
        if(RunningTotal > 0){
            RunningTotal = RunningTotal * -1;
            let std = String(format: "%.0f", RunningTotal)
            displaylabel.text = std;
//            workings = std;
        }
        else{
            RunningTotal = RunningTotal * -1;
            let std = String(format: "%.0f", RunningTotal)
            displaylabel.text = std;
//            workings = std;
        }
    }
    @IBAction func divide(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "/"
        displaylabel.text = (temp != "") ? resultFormatter(temp) : ""
          if temp != "" {
              //            inChainmode = true
              if num2 != ""{
                  inChainmode = true
                  
                  if opChange {
                      result = String(Double(temp)! / Double(num2)!)
                      print(result)
                      if result == "inf"{
                        displaylabel.text! = "Error"
                      }else{
                        displaylabel.text! = resultFormatter(result)
                      }
                  }
              }
          }
          opChange = true
        
    }
    
    @IBAction func multiplication(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "*"
        currNum=""
       displaylabel.text = (temp != "") ? resultFormatter(temp) : ""
         
        opChange = true
    }
    @IBAction func minus(_ sender: UIButton) {
        if(num1 == ""){
            num1 = "0"
        }
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "-"
        currNum=""
        displaylabel.text = (temp != "") ? resultFormatter(temp) : ""
        opChange = true
        
    }
    @IBAction func plus(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "+"
        currNum=""
       displaylabel.text = (temp != "") ? resultFormatter(temp) : ""
        opChange = true
    }
    
    @IBAction func equals(_ sender: UIButton) {
        var res = ""
        switch operation {
        case "+":
            
        if currNum != "" {
                res = String(Double(num1)! + Double(currNum)!)
                displaylabel.text = resultFormatter(res)
                 num2 = currNum
            }else{
                res = String(Double(num1)! + Double(num2)!)
                displaylabel.text = resultFormatter(res)
            }
            num1 = res
            
            break
        case "*":
            if currNum != "" {
                res = String(Double(num1)! * Double(currNum)!)
                displaylabel.text = resultFormatter(res)
            }else{
                res = String(Double(num1)! * Double(num2)!)
                displaylabel.text = resultFormatter(res)
            }
            num1 = res
            
            break
        case "-":
            if currNum != "" {
                res = String(Double(num1)! - Double(currNum)!)
               displaylabel.text = resultFormatter(res)
                
            }else{
                res = String(Double(num1)! - Double(num2)!)
               displaylabel.text = resultFormatter(res)
               
            }
            num1 = res
            break
        case "/":
            if displaylabel.text == "Error"{
                clearAll()
            }else{
                if currNum != "" {
                    res = String(Double(num1)! / Double(currNum)!)
                    if res == "inf"{
                        displaylabel.text! = "Error"
                        return
                    }else{
                        displaylabel.text = resultFormatter(res)
                    }
                }else{
                    res = String(Double(num1)! / Double(num2)!)
                    if res == "inf"{
                        displaylabel.text! = "Error"
                        return
                    }else{
                        displaylabel.text = resultFormatter(res)
                    }
                }
                num1 = res
            }
            break
        case "%":
            if currNum != "" {
                displaylabel.text = resultFormatter(res)
                let s1 = Double(num1)!
                let s2 = Double(currNum)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                 num2 = currNum
            }else{
                let s1 = Double(num1)!
                let s2 = Double(num2)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                displaylabel.text = resultFormatter(res)
            }
            num1 = res
            
            break
            
        default:
            print("IOS")
        }
    
    }
    
    @IBAction func remainder(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "%"
        currNum=""
       displaylabel.text = (temp != "") ? resultFormatter(temp) : ""
         
        opChange = true
    }
   
    @IBAction func Dot(_ sender: UIButton) {
        setData(".")
    }
    
    
    @IBAction func Seven(_ sender: UIButton) {
        setData("7")
    }
    @IBAction func Eight(_ sender: UIButton) {
        setData("8")
    }
    
    @IBAction func Nine(_ sender: UIButton) {
        setData("9")
    }
    @IBAction func Four(_ sender: UIButton) {
        setData("4")
    }
    
    @IBAction func Five(_ sender: UIButton) {
        setData("5")
    }
    @IBAction func Six(_ sender: UIButton) {
        setData("6")
    }
    
    @IBAction func One(_ sender: UIButton) {
        setData("1")
    }
    @IBAction func Two(_ sender: UIButton) {
        setData("2")
    }
    @IBAction func Three(_ sender: UIButton) {
        setData("3")
    }
    @IBAction func Zero(_ sender: UIButton) {
        setData("0")
    }
    
    
}

